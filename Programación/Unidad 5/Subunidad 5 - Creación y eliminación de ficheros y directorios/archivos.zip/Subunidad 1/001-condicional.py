# El código solo se ejecuta si la expresión es verdadera
edad = 25
if edad < 20:
    print("Eres un joven")
else:
    print("Ya no eres un joven")
