edad = 47

assert edad == 48, "No es correcto"
