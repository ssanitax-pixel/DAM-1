edad = 47
try:
    assert edad == 48, "No es correcto"
except:
    print("Error determinado")
