print(4/0)

print("Y el programa continua")

