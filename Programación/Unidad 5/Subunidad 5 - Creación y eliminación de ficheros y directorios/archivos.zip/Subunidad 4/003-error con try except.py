try:
    print(4/0)
except:
    print("No puedo ejecutar eso")
    
print("Y el programa continua")
