import math
def raizSegura(numero):
    resultado = numero*numero

print(raizSegura(16))

