# Enunciado
Ejercicio: Clasificación de jugadores de baloncesto por edad






Menores de 8 años -> Pre-mini

De 8 a 11 años -> Mini

De 12 a 15 años -> Infantil

De 16 a 17 años -> Cadete

De 18 a 20 años -> Junior

De 21 años o más -> Senior



# Escribir pseudocódigo

- Pide al usuario su edad (solucionar con input)
- Si la edad es menor de 8, pre-mini
- 
- 

