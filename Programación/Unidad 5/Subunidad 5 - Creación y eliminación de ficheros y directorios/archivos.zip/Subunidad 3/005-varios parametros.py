# Las funciones deben escribirse con camelCase
# Deben tener un verbo (infinitivo o imperativo) y un objeto directo
# Deben tener un nombre descriptivo

def diHola(nombre,edad):
    print("Hola",nombre,",tienes",edad,"años y yo te saludo")
    
diHola("Jose Vicente",47)
diHola("Jorge",48)
