from funciondivision import hazDivision

print(hazDivision(4,"3"))
