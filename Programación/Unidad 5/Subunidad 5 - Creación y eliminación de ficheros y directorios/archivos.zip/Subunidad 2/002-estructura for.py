# cuento los días del mes
for dia in range(1,31):
    print("Hoy es el dia",dia,"del mes")
