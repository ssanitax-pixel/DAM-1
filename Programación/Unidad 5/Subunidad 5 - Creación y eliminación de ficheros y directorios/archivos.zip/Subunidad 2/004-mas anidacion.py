# cuento los días del mes
for anio in range(1978,2026):
    for mes in range(1,13):
        for dia in range(1,31):
            print("Hoy es el dia",dia,"del mes",mes,"del año",anio)
