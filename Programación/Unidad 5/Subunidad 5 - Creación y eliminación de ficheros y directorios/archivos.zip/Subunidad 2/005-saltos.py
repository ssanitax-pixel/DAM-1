for pares in range(0,100,2):
    print(pares)
