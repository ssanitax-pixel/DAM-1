# cuento los días del mes
print("Hoy es el día 1 del mes")
print("Hoy es el día 2 del mes")
print("Hoy es el día 3 del mes")
print("Hoy es el día 4 del mes")
