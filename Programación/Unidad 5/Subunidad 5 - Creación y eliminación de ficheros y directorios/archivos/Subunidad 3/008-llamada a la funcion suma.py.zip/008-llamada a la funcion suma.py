# from archivo import funcion, funcion2, funcion3

from funcionsuma import calculaSuma

print(calculaSuma(4,3))
