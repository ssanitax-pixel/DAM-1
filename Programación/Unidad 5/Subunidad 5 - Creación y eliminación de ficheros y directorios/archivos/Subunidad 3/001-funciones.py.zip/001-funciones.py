# Las funciones deben escribirse con camelCase
# Deben tener un verbo (infinitivo o imperativo) y un objeto directo
# Deben tener un nombre descriptivo

def diHola():
    print("Te digo hola")
