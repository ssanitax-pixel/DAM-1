def hazDivision(dividendo,divisor):
    if divisor != 0:
        resultado = dividendo/divisor
    else:
        resultado = 0
    return resultado
    
print(hazDivision(4,"a"))
