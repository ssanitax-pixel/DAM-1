dia = 1

while dia < 31:
    print("hoy es el día",dia,"del mes")
    dia +=1 # dia = dia + 1
    
