for pares in range(1,100,2):
    print(pares)
