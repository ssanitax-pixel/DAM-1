# El código solo se ejecuta si la expresión es verdadera
edad = 47

if edad < 10:
    print("Eres un niño")
else if edad<= 10 and edad  < 20:
    print("Eres un adolescente")
elif edad >= 20 and edad < 30:
    print("Eres un joven")
else:
    print("Ya no eres un joven")
