# esto no hay que hacerlo

edad = 47

if edad < 30:
    if edad < 20:
        print("Eres muuuuy joven")
    else:
        print("Eres un joven")
else:
    if edad < 40:
        print("Eres bastante joven")
    else:
        print("Ya no eres joven")
