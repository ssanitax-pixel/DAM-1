dia = 1

while dia < 31:
    print("hoy es el día",dia,"del mes")
    
