try:
    print(4/0)
    print("Intento conectarme a la base de datos")
    print("Pero falla")
except:
    print("No puedo ejecutar eso")
    print("Pues por lo menos guardo los datos a un archivo local temporal")
    
print("Y el programa continua")
