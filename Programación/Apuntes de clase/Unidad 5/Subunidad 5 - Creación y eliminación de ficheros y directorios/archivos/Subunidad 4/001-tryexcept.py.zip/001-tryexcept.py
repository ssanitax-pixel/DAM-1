try:
    print(4+3)
except:
    print("Ha ocurrido un error")
    
print("Pero el programa sigue corriendo")
