'''
Función correcta:
Nombre: Verbo imperativo (o infinitivo) + objeto directo
Usa camelCase
Debe tener parámetros de entrada
Debe tener una salida con return
Debemos evitar prints y otros recursos de salida dentro de la función
'''

def calculaSuma(operando1,operando2):
    resultado = operando1 + operando2
    return resultado
