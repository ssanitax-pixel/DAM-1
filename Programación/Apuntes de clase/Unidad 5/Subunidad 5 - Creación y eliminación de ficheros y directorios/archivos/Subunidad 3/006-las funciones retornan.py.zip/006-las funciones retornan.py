# Las funciones deben escribirse con camelCase
# Deben tener un verbo (infinitivo o imperativo) y un objeto directo
# Deben tener un nombre descriptivo
# Parámetro es el valor que entra en la función
# Return es la forma limpia de sacar información de la función

def diHola(nombre,edad):
    return "Hola",+nombre+", tienes"+str(edad)+"años y yo te saludo"
    
diHola("Jose Vicente",47)
diHola("Jorge",48)
